package Game.Ite;

public class Axe extends Items {
    
    public Axe(){
        super("Hache");
        this.dmg=5;
    }
}
