package Game.Ite;

public class Sword extends Items {
    
    public Sword(){
        super("Epee");
        this.dmg=4;
    }
}