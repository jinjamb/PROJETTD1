package Game.Ite;

public class Stick extends Items {
    
    public Stick(){
        super("Baton");
        this.dmg=2;
    }
}